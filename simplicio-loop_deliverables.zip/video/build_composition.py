#!/usr/bin/env python3
"""Gera uma composição hyperframes 0.7.x (HTML→MP4 determinístico) por idioma.

Lê video/storyboard.master.json (visual/efeitos/timing) + video/lang/<lang>.json (caption/narração)
e escreve video/hyperframes/<lang>/index.html, pronto para:
    npx hyperframes lint   (dentro de video/hyperframes/<lang>/)
    npx hyperframes render video/hyperframes/<lang> -o out.mp4 -f 30 -q high

Contrato espelhado de scripts/video_evidence.py (schema 0.7.x):
  #root[data-composition-id="main"][data-start][data-duration][data-width][data-height]
  .clip#sN[data-start][data-duration][data-track-index]  gated pelo framework
  timeline GSAP pausada registrada em window.__timelines["main"]

Uso:
    python3 video/build_composition.py            # todos os idiomas
    python3 video/build_composition.py en pt-BR   # subconjunto
"""
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
LANG_DIR = HERE / "lang"
OUT_DIR = HERE / "hyperframes"
LANGS = ["en", "zh-CN", "es", "pt-BR"]

W, H = 1920, 1080


def _esc(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


# Acento visual por cena (SVG/CSS deterministicos, sem screenshots).
ACCENT = {
    "hook": ("#7C3AED", "∞"),
    "problem": ("#FF5C5C", "≢"),
    "preflight": ("#00E08A", "✓✓✓"),
    "discover_dag": ("#2563EB", "⬡"),
    "cycle": ("#00E08A", "▸▸▸"),
    "quality_safety": ("#FF5C5C", "🔒"),
    "token_economy": ("#00E08A", "96%"),
    "evidence_loop": ("#7C3AED", "⟳"),
    "video_evidence": ("#2563EB", "🎬"),
    "runtimes": ("#2563EB", "11"),
    "always_on": ("#00E08A", "24/7"),
    "cta": ("#7C3AED", "∞"),
}


def build(lang: str, storyboard: dict) -> Path:
    data = json.loads((LANG_DIR / f"{lang}.json").read_text(encoding="utf-8"))
    scenes_master = {s["id"]: s for s in storyboard["scenes"]}
    palette = storyboard["video"]["style"]["palette"]

    clips, fades, total = [], [], 0.0
    for sc in data["scenes"]:
        sid = sc["id"]
        m = scenes_master.get(sid, {})
        key = sc.get("key", m.get("key", ""))
        start = float(sc["start_s"])
        dur = float(sc["duration_s"])
        total = max(total, start + dur)
        color, glyph = ACCENT.get(key, ("#00E08A", "∞"))
        data_chip = _esc(str(m.get("headline_data", "")))
        cap = _esc(sc.get("caption", ""))
        clips.append(
            f'      <div class="clip scene-{key}" id="s{sid}" data-start="{_g(start)}" '
            f'data-duration="{_g(dur)}" data-track-index="1">\n'
            f'        <div class="glow" style="--c:{color}"></div>\n'
            f'        <div class="glyph" id="g{sid}" style="--c:{color}">{glyph}</div>\n'
            f'        <div class="num">{sid:02d} / 12</div>\n'
            f'        <div class="cap" id="c{sid}">{cap}</div>\n'
            f'        <div class="chip" id="d{sid}">{data_chip}</div>\n'
            f'      </div>'
        )
        # animações: clip fade+rise, glyph pop, caption slide, chip fade — todas na janela do clip
        fades.append(
            f'    tl.fromTo("#s{sid}", {{opacity:0, y:36}}, {{opacity:1, y:0, duration:0.5, ease:"power2.out"}}, {_g(start)});\n'
            f'    tl.fromTo("#g{sid}", {{scale:0.4, opacity:0}}, {{scale:1, opacity:1, duration:0.6, ease:"back.out(2)"}}, {_g(start + 0.1)});\n'
            f'    tl.fromTo("#c{sid}", {{opacity:0, y:18}}, {{opacity:1, y:0, duration:0.5}}, {_g(start + 0.25)});\n'
            f'    tl.fromTo("#d{sid}", {{opacity:0}}, {{opacity:0.92, duration:0.5}}, {_g(start + 0.45)});\n'
            f'    tl.to("#s{sid}", {{opacity:0, duration:0.4, ease:"power1.in"}}, {_g(start + dur - 0.4)});\n'
            f'    tl.set("#s{sid}", {{opacity:0}}, {_g(start + dur)});'
        )

    proj = OUT_DIR / lang
    assets = proj / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    # logo dentro do projeto (hyperframes serve o dir; asset fora da árvore não resolve)
    logo_src = REPO / "assets" / "simplicio-loop-logo.png"
    if logo_src.exists():
        shutil.copy2(logo_src, assets / "logo.png")

    html = TEMPLATE.format(
        lang=lang, title=_esc(data.get("title", "simplicio-loop")),
        w=W, h=H, duration=_g(total),
        bg=storyboard["video"]["style"]["background"],
        text=storyboard["video"]["style"]["text_light"],
        purple=palette["skills_purple"], green=palette["accent_green"], blue=palette["runtimes_blue"],
        clips="\n".join(clips), fades="\n".join(fades),
        brand="github.com/wesleysimplicio/simplicio-loop",
    )
    (proj / "index.html").write_text(html, encoding="utf-8")
    return proj / "index.html"


def _g(x: float) -> str:
    return "%g" % float(x)


TEMPLATE = """<!doctype html>
<html lang="{lang}">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width={w}, height={h}" />
  <title>{title}</title>
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    * {{ margin:0; padding:0; box-sizing:border-box; }}
    html, body {{ width:{w}px; height:{h}px; overflow:hidden; background:{bg};
      font-family:Arial,Helvetica,sans-serif; color:{text}; }}
    body::before {{ content:""; position:absolute; inset:0;
      background:
        radial-gradient(1200px 700px at 50% 30%, rgba(124,58,237,.18), transparent 60%),
        radial-gradient(900px 600px at 80% 90%, rgba(0,224,138,.12), transparent 60%);
      background-image:
        linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px);
      background-size:100% 100%, 64px 64px, 64px 64px; }}
    .clip {{ position:absolute; inset:0; display:flex; flex-direction:column;
      align-items:center; justify-content:center; gap:26px; padding:0 140px; opacity:0; }}
    .glow {{ position:absolute; width:760px; height:760px; border-radius:50%;
      background:radial-gradient(circle, color-mix(in srgb, var(--c) 38%, transparent), transparent 62%);
      filter:blur(18px); z-index:0; }}
    .glyph {{ position:relative; z-index:1; font-size:150px; font-weight:800; line-height:1;
      color:var(--c); text-shadow:0 0 50px color-mix(in srgb, var(--c) 60%, transparent); }}
    .num {{ position:relative; z-index:1; font-family:"Courier New",monospace;
      font-size:20px; letter-spacing:4px; opacity:.55; }}
    .cap {{ position:relative; z-index:1; font-size:58px; font-weight:700; line-height:1.12;
      text-align:center; max-width:1400px; }}
    .chip {{ position:relative; z-index:1; font-family:"Courier New",monospace; font-size:24px;
      line-height:1.5; text-align:center; max-width:1500px; color:{green}; opacity:0;
      background:rgba(0,224,138,.07); border:1px solid rgba(0,224,138,.22);
      border-radius:14px; padding:14px 26px; }}
    .scene-problem .chip {{ color:#FF8A8A; background:rgba(255,92,92,.08);
      border-color:rgba(255,92,92,.25); }}
    .scene-runtimes .chip, .scene-discover_dag .chip, .scene-video_evidence .chip {{
      color:#7FB2FF; background:rgba(37,99,235,.10); border-color:rgba(37,99,235,.28); }}
    .brand {{ position:absolute; left:46px; bottom:34px; z-index:2;
      font-family:"Courier New",monospace; font-size:18px; opacity:.5; }}
    .loopmark {{ position:absolute; right:48px; bottom:30px; z-index:2; font-size:40px;
      color:{purple}; opacity:.8; }}
    .logo {{ position:absolute; left:44px; top:30px; z-index:2; height:46px; opacity:.92; }}
  </style>
</head>
<body>
  <div id="root" data-composition-id="main" data-start="0" data-duration="{duration}"
       data-width="{w}" data-height="{h}">
{clips}
    <img class="logo" src="assets/logo.png" alt="simplicio-loop" />
    <div class="brand">{brand}</div>
    <div class="loopmark">&#8734;</div>
  </div>
  <script>
    window.__timelines = window.__timelines || {{}};
    var tl = gsap.timeline({{ paused: true }});
{fades}
    window.__timelines["main"] = tl;
  </script>
</body>
</html>
"""


def main() -> int:
    storyboard = json.loads((HERE / "storyboard.master.json").read_text(encoding="utf-8"))
    targets = sys.argv[1:] or LANGS
    for lang in targets:
        if lang not in LANGS:
            print(f"skip: unknown lang {lang}")
            continue
        out = build(lang, storyboard)
        print(f"wrote {out.relative_to(REPO)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
